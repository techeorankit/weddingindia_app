<?php
// ============================================================
//  Matches API - Find compatible partners
//  GET /api/matches.php?action=find   => Find matches based on preferences
//  GET /api/matches.php?action=view&id=<user_id>   => View specific profile
// ============================================================

require_once 'config.php';

$action = $_GET['action'] ?? 'find';
$userId = getAuthUserId();

switch ($action) {
    case 'find':
        findMatches($userId);
        break;
    case 'view':
        $profileId = (int)($_GET['id'] ?? 0);
        if ($profileId <= 0) sendError(400, 'Profile ID required');
        viewProfile($profileId);
        break;
    default:
        sendError(404, 'Invalid action');
}

// ============================================================
// Find Matches Based on User Preferences
// ============================================================
function findMatches($userId) {
    $db = getDB();
    
    // Get current user's partner preferences
    $stmt = $db->prepare("
        SELECT age_min, age_max, religion_id, min_height_id, max_height_id, income_id
        FROM user_partner_preference
        WHERE user_id = ?
    ");
    $stmt->execute([$userId]);
    $pref = $stmt->fetch();
    
    // Get current user's gender (to find opposite gender)
    $stmt = $db->prepare("SELECT gender FROM user_profiles WHERE user_id = ?");
    $stmt->execute([$userId]);
    $userProfile = $stmt->fetch();
    $oppositeGender = $userProfile['gender'] === 'Male' ? 'Female' : 'Male';
    
    // Build dynamic query
    $query = "
        SELECT 
            u.id as user_id,
            p.full_name,
            p.profile_photo,
            CONCAT('" . UPLOAD_URL . "', p.profile_photo) as profile_photo_url,
            p.dob,
            YEAR(CURDATE()) - YEAR(p.dob) as age,
            p.gender,
            r.name as religion,
            s.name as state,
            ul.city,
            h.name as height,
            el.name as education,
            ue.profession
        FROM users u
        INNER JOIN user_profiles p ON p.user_id = u.id
        LEFT JOIN user_religion ur ON ur.user_id = u.id
        LEFT JOIN religions r ON r.id = ur.religion_id
        LEFT JOIN user_location ul ON ul.user_id = u.id
        LEFT JOIN states s ON s.id = ul.state_id
        LEFT JOIN user_habits uh ON uh.user_id = u.id
        LEFT JOIN heights h ON h.id = uh.height_id
        LEFT JOIN user_education ue ON ue.user_id = u.id
        LEFT JOIN education_levels el ON el.id = ue.education_id
        WHERE u.id != ?
        AND p.is_profile_complete = 1
        AND p.gender = ?
    ";
    
    $params = [$userId, $oppositeGender];
    
    // Apply preferences if set
    if ($pref) {
        if ($pref['age_min'] && $pref['age_max']) {
            $query .= " AND YEAR(CURDATE()) - YEAR(p.dob) BETWEEN ? AND ?";
            $params[] = $pref['age_min'];
            $params[] = $pref['age_max'];
        }
        
        if ($pref['religion_id']) {
            $query .= " AND ur.religion_id = ?";
            $params[] = $pref['religion_id'];
        }
        
        if ($pref['min_height_id'] && $pref['max_height_id']) {
            $query .= " AND uh.height_id BETWEEN ? AND ?";
            $params[] = $pref['min_height_id'];
            $params[] = $pref['max_height_id'];
        }
        
        if ($pref['income_id']) {
            $query .= " AND ue.income_id >= ?";
            $params[] = $pref['income_id'];
        }
    }
    
    $query .= " ORDER BY u.created_at DESC LIMIT 50";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $matches = $stmt->fetchAll();
    
    sendSuccess([
        'total' => count($matches),
        'matches' => $matches
    ], 'Matches found');
}

// ============================================================
// View Specific Profile (Public View)
// ============================================================
function viewProfile($profileId) {
    $db = getDB();
    
    $stmt = $db->prepare("
        SELECT
            u.id,
            p.profile_for, p.full_name, p.dob,
            YEAR(CURDATE()) - YEAR(p.dob) as age,
            p.gender, p.bio,
            CONCAT('" . UPLOAD_URL . "', p.profile_photo) as profile_photo_url,
            r.name as religion, ur.caste, mt.name as mother_tongue,
            s.name as state, ul.city,
            el.name as education, ue.profession, ir.name as income,
            h.name as height, uh.weight,
            eh.name as eating_habit, sh.name as smoking_habit,
            dh.name as drinking_habit, d.name as disability,
            ms.name as marital_status, bt.name as body_type,
            c.name as complexion, bg.name as blood_group
        FROM users u
        INNER JOIN user_profiles p ON p.user_id = u.id
        LEFT JOIN user_religion ur ON ur.user_id = u.id
        LEFT JOIN religions r ON r.id = ur.religion_id
        LEFT JOIN mother_tongues mt ON mt.id = ur.mother_tongue_id
        LEFT JOIN user_location ul ON ul.user_id = u.id
        LEFT JOIN states s ON s.id = ul.state_id
        LEFT JOIN user_education ue ON ue.user_id = u.id
        LEFT JOIN education_levels el ON el.id = ue.education_id
        LEFT JOIN income_ranges ir ON ir.id = ue.income_id
        LEFT JOIN user_habits uh ON uh.user_id = u.id
        LEFT JOIN heights h ON h.id = uh.height_id
        LEFT JOIN eating_habits eh ON eh.id = uh.eating_habit_id
        LEFT JOIN smoking_habits sh ON sh.id = uh.smoking_habit_id
        LEFT JOIN drinking_habits dh ON dh.id = uh.drinking_habit_id
        LEFT JOIN disabilities d ON d.id = uh.disability_id
        LEFT JOIN marital_statuses ms ON ms.id = uh.marital_status_id
        LEFT JOIN body_types bt ON bt.id = uh.body_type_id
        LEFT JOIN complexions c ON c.id = uh.complexion_id
        LEFT JOIN blood_groups bg ON bg.id = uh.blood_group_id
        WHERE u.id = ? AND p.is_profile_complete = 1
    ");
    $stmt->execute([$profileId]);
    $profile = $stmt->fetch();
    
    if (!$profile) {
        sendError(404, 'Profile not found or incomplete');
    }
    
    // Get all photos
    $stmt = $db->prepare("
        SELECT CONCAT('" . UPLOAD_URL . "', photo_path) as url, is_primary 
        FROM user_photos 
        WHERE user_id = ? 
        ORDER BY is_primary DESC, id DESC
    ");
    $stmt->execute([$profileId]);
    $profile['photos'] = $stmt->fetchAll();
    
    sendSuccess($profile);
}
