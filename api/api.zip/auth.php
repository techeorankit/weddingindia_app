<?php
// ============================================================
//  Authentication API
//  POST /api/auth.php?action=send_otp     => OTP bhejna
//  POST /api/auth.php?action=verify_otp   => OTP verify karna
//  POST /api/auth.php?action=logout       => Logout
// ============================================================

require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'send_otp':
        sendOtp();
        break;
    case 'verify_otp':
        verifyOtp();
        break;
    case 'logout':
        logout();
        break;
    default:
        sendError(404, 'Invalid action');
}

// ============================================================
// OTP Bhejna
// ============================================================
function sendOtp() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') sendError(405, 'Method not allowed');

    $input = getInput();
    $phone = trim($input['phone'] ?? '');
    $countryCode = trim($input['country_code'] ?? '+91');

    if (empty($phone) || !preg_match('/^\d{10}$/', $phone)) {
        sendError(400, 'Valid 10-digit phone number required');
    }

    $db = getDB();

    // Check karo user exist karta hai ya nahi, nahi to create karo
    $stmt = $db->prepare("SELECT id FROM users WHERE phone = ? AND country_code = ?");
    $stmt->execute([$phone, $countryCode]);
    $user = $stmt->fetch();

    // OTP generate karo (production mein real SMS bhejna hoga)
    $otp = str_pad(rand(1000, 9999), 4, '0', STR_PAD_LEFT);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+' . OTP_EXPIRY_MINUTES . ' minutes'));

    if ($user) {
        // Existing user - OTP update karo
        $stmt = $db->prepare("UPDATE users SET otp = ?, otp_expires_at = ? WHERE id = ?");
        $stmt->execute([$otp, $expiresAt, $user['id']]);
    } else {
        // Naya user create karo
        $stmt = $db->prepare("INSERT INTO users (phone, country_code, otp, otp_expires_at) VALUES (?, ?, ?, ?)");
        $stmt->execute([$phone, $countryCode, $otp, $expiresAt]);
    }

    // TODO: Yahan apna SMS API integrate karo (Twilio, MSG91, etc.)
    // abhi development ke liye OTP response mein bhej rahe hain
    // Production mein neeche wali line hata dena aur sirf message bhejna
    $responseData = ['otp_debug' => $otp]; // PRODUCTION MEIN REMOVE KARO

    sendSuccess($responseData, "OTP sent to $countryCode $phone");
}

// ============================================================
// OTP Verify Karna
// ============================================================
function verifyOtp() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') sendError(405, 'Method not allowed');

    $input = getInput();
    $phone = trim($input['phone'] ?? '');
    $countryCode = trim($input['country_code'] ?? '+91');
    $otp = trim($input['otp'] ?? '');

    if (empty($phone) || empty($otp)) {
        sendError(400, 'Phone and OTP are required');
    }

    $db = getDB();

    $stmt = $db->prepare("SELECT id, otp, otp_expires_at, is_verified FROM users WHERE phone = ? AND country_code = ?");
    $stmt->execute([$phone, $countryCode]);
    $user = $stmt->fetch();

    if (!$user) {
        sendError(404, 'Phone number not found. Please request OTP first.');
    }

    if ($user['otp'] !== $otp) {
        sendError(400, 'Invalid OTP');
    }

    if (strtotime($user['otp_expires_at']) < time()) {
        sendError(400, 'OTP expired. Please request a new one.');
    }

    // Token generate karo
    $token = generateToken($user['id']);
    $tokenExpiry = date('Y-m-d H:i:s', strtotime('+' . TOKEN_EXPIRY_DAYS . ' days'));

    // User ko verified mark karo aur token save karo
    $stmt = $db->prepare("UPDATE users SET is_verified = 1, auth_token = ?, token_expires_at = ?, otp = NULL, otp_expires_at = NULL WHERE id = ?");
    $stmt->execute([$token, $tokenExpiry, $user['id']]);

    // Profile check karo - complete hai ya nahi
    $stmt = $db->prepare("SELECT is_profile_complete FROM user_profiles WHERE user_id = ?");
    $stmt->execute([$user['id']]);
    $profile = $stmt->fetch();

    sendSuccess([
        'user_id'              => $user['id'],
        'token'                => $token,
        'is_profile_complete'  => $profile ? (bool)$profile['is_profile_complete'] : false,
    ], 'OTP verified successfully');
}

// ============================================================
// Logout
// ============================================================
function logout() {
    $userId = getAuthUserId();
    $db = getDB();
    $stmt = $db->prepare("UPDATE users SET auth_token = NULL, token_expires_at = NULL WHERE id = ?");
    $stmt->execute([$userId]);
    sendSuccess([], 'Logged out successfully');
}
