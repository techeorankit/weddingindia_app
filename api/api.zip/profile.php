<?php
// ============================================================
//  User Profile API (Protected - Token Required)
//
//  POST /api/profile.php?action=save_basic       => Basic details save
//  POST /api/profile.php?action=save_religion    => Religion & community
//  POST /api/profile.php?action=save_location    => State & city
//  POST /api/profile.php?action=save_education   => Education & career
//  POST /api/profile.php?action=save_habits      => Habits & physical details
//  POST /api/profile.php?action=save_preference  => Partner preference
//  POST /api/profile.php?action=save_about       => Bio/About me
//  POST /api/profile.php?action=save_profile_for => Profile for (Myself/Son etc)
//  GET  /api/profile.php?action=get              => Full profile fetch
//  POST /api/profile.php?action=upload_photo     => Photo upload
// ============================================================

require_once 'config.php';

$action = $_GET['action'] ?? '';
$userId = getAuthUserId(); // Token check - agar nahi hai to 401 return karta hai

switch ($action) {
    case 'save_profile_for': saveProfileFor($userId); break;
    case 'save_basic':       saveBasicDetails($userId); break;
    case 'save_religion':    saveReligion($userId); break;
    case 'save_location':    saveLocation($userId); break;
    case 'save_education':   saveEducation($userId); break;
    case 'save_habits':      saveHabits($userId); break;
    case 'save_preference':  savePartnerPreference($userId); break;
    case 'save_about':       saveAboutMe($userId); break;
    case 'upload_photo':     uploadPhoto($userId); break;
    case 'get':              getProfile($userId); break;
    default: sendError(404, 'Invalid action');
}

// ============================================================
// Profile For Save
// ============================================================
function saveProfileFor($userId) {
    $input = getInput();
    $profileFor = trim($input['profile_for'] ?? '');

    $allowed = ['Myself', 'Son', 'Daughter', 'Brother', 'Sister', 'Friend'];
    if (!in_array($profileFor, $allowed)) {
        sendError(400, 'Invalid profile_for value');
    }

    $db = getDB();
    $stmt = $db->prepare("INSERT INTO user_profiles (user_id, profile_for) VALUES (?, ?)
                          ON DUPLICATE KEY UPDATE profile_for = VALUES(profile_for)");
    $stmt->execute([$userId, $profileFor]);

    sendSuccess(['profile_for' => $profileFor], 'Profile For saved');
}

// ============================================================
// Basic Details Save
// ============================================================
function saveBasicDetails($userId) {
    $input = getInput();
    $fullName = trim($input['full_name'] ?? '');
    $dob      = trim($input['dob'] ?? '');        // Format: YYYY-MM-DD
    $gender   = trim($input['gender'] ?? '');

    if (empty($fullName)) sendError(400, 'Full name is required');
    if (empty($dob) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
        sendError(400, 'Valid date of birth required (YYYY-MM-DD format)');
    }
    if (!in_array($gender, ['Male', 'Female', 'Other'])) {
        sendError(400, 'Gender must be Male, Female, or Other');
    }

    $db = getDB();
    $stmt = $db->prepare("INSERT INTO user_profiles (user_id, full_name, dob, gender)
                          VALUES (?, ?, ?, ?)
                          ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), dob = VALUES(dob), gender = VALUES(gender)");
    $stmt->execute([$userId, $fullName, $dob, $gender]);

    sendSuccess([], 'Basic details saved');
}

// ============================================================
// Religion & Community Save
// ============================================================
function saveReligion($userId) {
    $input = getInput();
    $religionId     = (int)($input['religion_id'] ?? 0);
    $caste          = trim($input['caste'] ?? '');
    $motherTongueId = isset($input['mother_tongue_id']) ? (int)$input['mother_tongue_id'] : null;

    if ($religionId <= 0) sendError(400, 'religion_id is required');

    // Validate religion exists
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM religions WHERE id = ? AND is_active = 1");
    $stmt->execute([$religionId]);
    if (!$stmt->fetch()) sendError(400, 'Invalid religion_id');

    $stmt = $db->prepare("INSERT INTO user_religion (user_id, religion_id, caste, mother_tongue_id)
                          VALUES (?, ?, ?, ?)
                          ON DUPLICATE KEY UPDATE religion_id = VALUES(religion_id),
                          caste = VALUES(caste), mother_tongue_id = VALUES(mother_tongue_id)");
    $stmt->execute([$userId, $religionId, $caste ?: null, $motherTongueId]);

    sendSuccess([], 'Religion details saved');
}

// ============================================================
// Location Save
// ============================================================
function saveLocation($userId) {
    $input   = getInput();
    $stateId = (int)($input['state_id'] ?? 0);
    $city    = trim($input['city'] ?? '');

    if ($stateId <= 0) sendError(400, 'state_id is required');
    if (empty($city)) sendError(400, 'City is required');

    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM states WHERE id = ? AND is_active = 1");
    $stmt->execute([$stateId]);
    if (!$stmt->fetch()) sendError(400, 'Invalid state_id');

    $stmt = $db->prepare("INSERT INTO user_location (user_id, state_id, city)
                          VALUES (?, ?, ?)
                          ON DUPLICATE KEY UPDATE state_id = VALUES(state_id), city = VALUES(city)");
    $stmt->execute([$userId, $stateId, $city]);

    sendSuccess([], 'Location saved');
}

// ============================================================
// Education & Career Save
// ============================================================
function saveEducation($userId) {
    $input       = getInput();
    $educationId = (int)($input['education_id'] ?? 0);
    $profession  = trim($input['profession'] ?? '');
    $incomeId    = isset($input['income_id']) ? (int)$input['income_id'] : null;

    if ($educationId <= 0) sendError(400, 'education_id is required');

    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM education_levels WHERE id = ? AND is_active = 1");
    $stmt->execute([$educationId]);
    if (!$stmt->fetch()) sendError(400, 'Invalid education_id');

    $stmt = $db->prepare("INSERT INTO user_education (user_id, education_id, profession, income_id)
                          VALUES (?, ?, ?, ?)
                          ON DUPLICATE KEY UPDATE education_id = VALUES(education_id),
                          profession = VALUES(profession), income_id = VALUES(income_id)");
    $stmt->execute([$userId, $educationId, $profession ?: null, $incomeId]);

    sendSuccess([], 'Education details saved');
}

// ============================================================
// Habits & Physical Details Save
// ============================================================
function saveHabits($userId) {
    $input = getInput();

    $heightId        = isset($input['height_id'])         ? (int)$input['height_id']         : null;
    $weight          = trim($input['weight'] ?? '');
    $eatingHabitId   = isset($input['eating_habit_id'])   ? (int)$input['eating_habit_id']   : null;
    $smokingHabitId  = isset($input['smoking_habit_id'])  ? (int)$input['smoking_habit_id']  : null;
    $drinkingHabitId = isset($input['drinking_habit_id']) ? (int)$input['drinking_habit_id'] : null;
    $disabilityId    = isset($input['disability_id'])     ? (int)$input['disability_id']     : null;
    $maritalStatusId = isset($input['marital_status_id']) ? (int)$input['marital_status_id'] : null;
    $bodyTypeId      = isset($input['body_type_id'])      ? (int)$input['body_type_id']      : null;
    $complexionId    = isset($input['complexion_id'])     ? (int)$input['complexion_id']     : null;
    $bloodGroupId    = isset($input['blood_group_id'])    ? (int)$input['blood_group_id']    : null;

    $db = getDB();
    $stmt = $db->prepare("INSERT INTO user_habits
        (user_id, height_id, weight, eating_habit_id, smoking_habit_id, drinking_habit_id,
         disability_id, marital_status_id, body_type_id, complexion_id, blood_group_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        height_id = VALUES(height_id), weight = VALUES(weight),
        eating_habit_id = VALUES(eating_habit_id), smoking_habit_id = VALUES(smoking_habit_id),
        drinking_habit_id = VALUES(drinking_habit_id), disability_id = VALUES(disability_id),
        marital_status_id = VALUES(marital_status_id), body_type_id = VALUES(body_type_id),
        complexion_id = VALUES(complexion_id), blood_group_id = VALUES(blood_group_id)");

    $stmt->execute([
        $userId, $heightId, $weight ?: null, $eatingHabitId, $smokingHabitId,
        $drinkingHabitId, $disabilityId, $maritalStatusId, $bodyTypeId, $complexionId, $bloodGroupId
    ]);

    sendSuccess([], 'Habits & details saved');
}

// ============================================================
// Partner Preference Save
// ============================================================
function savePartnerPreference($userId) {
    $input = getInput();

    $ageMin      = max(18, (int)($input['age_min'] ?? 18));
    $ageMax      = min(60, (int)($input['age_max'] ?? 35));
    $religionId  = isset($input['religion_id'])   ? (int)$input['religion_id']  : null;
    $minHeightId = isset($input['min_height_id'])  ? (int)$input['min_height_id'] : null;
    $maxHeightId = isset($input['max_height_id'])  ? (int)$input['max_height_id'] : null;
    $incomeId    = isset($input['income_id'])      ? (int)$input['income_id']    : null;

    if ($ageMin > $ageMax) sendError(400, 'age_min cannot be greater than age_max');

    $db = getDB();
    $stmt = $db->prepare("INSERT INTO user_partner_preference
        (user_id, age_min, age_max, religion_id, min_height_id, max_height_id, income_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        age_min = VALUES(age_min), age_max = VALUES(age_max),
        religion_id = VALUES(religion_id), min_height_id = VALUES(min_height_id),
        max_height_id = VALUES(max_height_id), income_id = VALUES(income_id)");

    $stmt->execute([$userId, $ageMin, $ageMax, $religionId, $minHeightId, $maxHeightId, $incomeId]);

    sendSuccess([], 'Partner preference saved');
}

// ============================================================
// About Me / Bio Save
// ============================================================
function saveAboutMe($userId) {
    $input = getInput();
    $bio   = trim($input['bio'] ?? '');

    if (strlen($bio) < 20) sendError(400, 'Bio must be at least 20 characters');
    if (strlen($bio) > 500) sendError(400, 'Bio cannot exceed 500 characters');

    $db = getDB();
    $stmt = $db->prepare("INSERT INTO user_profiles (user_id, bio) VALUES (?, ?)
                          ON DUPLICATE KEY UPDATE bio = VALUES(bio)");
    $stmt->execute([$userId, $bio]);

    // Profile complete mark karo
    markProfileComplete($db, $userId);

    sendSuccess([], 'About me saved');
}

// ============================================================
// Photo Upload
// ============================================================
function uploadPhoto($userId) {
    if (empty($_FILES['photo'])) {
        sendError(400, 'Photo file is required');
    }

    $file = $_FILES['photo'];

    // Validate
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!in_array($file['type'], $allowedTypes)) {
        sendError(400, 'Only JPG, PNG, WebP images allowed');
    }
    if ($file['size'] > MAX_FILE_SIZE) {
        sendError(400, 'File size cannot exceed 5MB');
    }

    // Upload directory create karo
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }

    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'user_' . $userId . '_' . time() . '.' . $ext;
    $filepath = UPLOAD_DIR . $filename;

    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        sendError(500, 'Failed to upload photo');
    }

    $db = getDB();

    // Check karo primary photo hai ya nahi
    $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM user_photos WHERE user_id = ?");
    $stmt->execute([$userId]);
    $count = $stmt->fetch()['cnt'];
    $isPrimary = ($count == 0) ? 1 : 0;

    $stmt = $db->prepare("INSERT INTO user_photos (user_id, photo_path, is_primary) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $filename, $isPrimary]);

    // Profile photo update karo agar primary hai
    if ($isPrimary) {
        $stmt = $db->prepare("UPDATE user_profiles SET profile_photo = ? WHERE user_id = ?");
        $stmt->execute([$filename, $userId]);
    }

    sendSuccess([
        'photo_url' => UPLOAD_URL . $filename,
        'is_primary' => (bool)$isPrimary,
    ], 'Photo uploaded successfully');
}

// ============================================================
// Full Profile Get
// ============================================================
function getProfile($userId) {
    $db = getDB();

    // Basic profile
    $stmt = $db->prepare("
        SELECT
            u.phone, u.country_code,
            p.profile_for, p.full_name, p.dob, p.gender, p.bio,
            p.is_profile_complete,
            CONCAT('" . UPLOAD_URL . "', p.profile_photo) as profile_photo_url
        FROM users u
        LEFT JOIN user_profiles p ON p.user_id = u.id
        WHERE u.id = ?
    ");
    $stmt->execute([$userId]);
    $profile = $stmt->fetch();

    if (!$profile) sendError(404, 'Profile not found');

    // Religion
    $stmt = $db->prepare("
        SELECT r.name as religion, ur.caste, mt.name as mother_tongue,
               ur.religion_id, ur.mother_tongue_id
        FROM user_religion ur
        LEFT JOIN religions r ON r.id = ur.religion_id
        LEFT JOIN mother_tongues mt ON mt.id = ur.mother_tongue_id
        WHERE ur.user_id = ?
    ");
    $stmt->execute([$userId]);
    $profile['religion'] = $stmt->fetch() ?: null;

    // Location
    $stmt = $db->prepare("
        SELECT s.name as state, ul.city, ul.state_id
        FROM user_location ul
        LEFT JOIN states s ON s.id = ul.state_id
        WHERE ul.user_id = ?
    ");
    $stmt->execute([$userId]);
    $profile['location'] = $stmt->fetch() ?: null;

    // Education
    $stmt = $db->prepare("
        SELECT el.name as education, ue.profession, ir.name as income,
               ue.education_id, ue.income_id
        FROM user_education ue
        LEFT JOIN education_levels el ON el.id = ue.education_id
        LEFT JOIN income_ranges ir ON ir.id = ue.income_id
        WHERE ue.user_id = ?
    ");
    $stmt->execute([$userId]);
    $profile['education'] = $stmt->fetch() ?: null;

    // Habits
    $stmt = $db->prepare("
        SELECT
            h.name as height, uh.weight,
            eh.name as eating_habit, sh.name as smoking_habit,
            dh.name as drinking_habit, d.name as disability,
            ms.name as marital_status, bt.name as body_type,
            c.name as complexion, bg.name as blood_group,
            uh.height_id, uh.eating_habit_id, uh.smoking_habit_id,
            uh.drinking_habit_id, uh.disability_id, uh.marital_status_id,
            uh.body_type_id, uh.complexion_id, uh.blood_group_id
        FROM user_habits uh
        LEFT JOIN heights h ON h.id = uh.height_id
        LEFT JOIN eating_habits eh ON eh.id = uh.eating_habit_id
        LEFT JOIN smoking_habits sh ON sh.id = uh.smoking_habit_id
        LEFT JOIN drinking_habits dh ON dh.id = uh.drinking_habit_id
        LEFT JOIN disabilities d ON d.id = uh.disability_id
        LEFT JOIN marital_statuses ms ON ms.id = uh.marital_status_id
        LEFT JOIN body_types bt ON bt.id = uh.body_type_id
        LEFT JOIN complexions c ON c.id = uh.complexion_id
        LEFT JOIN blood_groups bg ON bg.id = uh.blood_group_id
        WHERE uh.user_id = ?
    ");
    $stmt->execute([$userId]);
    $profile['habits'] = $stmt->fetch() ?: null;

    // Partner Preference
    $stmt = $db->prepare("
        SELECT pp.age_min, pp.age_max,
               r.name as religion, h1.name as min_height, h2.name as max_height,
               ir.name as income,
               pp.religion_id, pp.min_height_id, pp.max_height_id, pp.income_id
        FROM user_partner_preference pp
        LEFT JOIN religions r ON r.id = pp.religion_id
        LEFT JOIN heights h1 ON h1.id = pp.min_height_id
        LEFT JOIN heights h2 ON h2.id = pp.max_height_id
        LEFT JOIN income_ranges ir ON ir.id = pp.income_id
        WHERE pp.user_id = ?
    ");
    $stmt->execute([$userId]);
    $profile['partner_preference'] = $stmt->fetch() ?: null;

    // Photos
    $stmt = $db->prepare("SELECT id, CONCAT('" . UPLOAD_URL . "', photo_path) as url, is_primary FROM user_photos WHERE user_id = ? ORDER BY is_primary DESC, id DESC");
    $stmt->execute([$userId]);
    $profile['photos'] = $stmt->fetchAll();

    sendSuccess($profile);
}

// ============================================================
// Profile Complete Helper
// ============================================================
function markProfileComplete($db, $userId) {
    // Check karo sab required sections fill hain
    $stmt = $db->prepare("
        SELECT
            (SELECT COUNT(*) FROM user_profiles WHERE user_id = ? AND full_name IS NOT NULL) as has_basic,
            (SELECT COUNT(*) FROM user_religion WHERE user_id = ?) as has_religion,
            (SELECT COUNT(*) FROM user_location WHERE user_id = ?) as has_location,
            (SELECT COUNT(*) FROM user_education WHERE user_id = ?) as has_education,
            (SELECT COUNT(*) FROM user_habits WHERE user_id = ?) as has_habits
    ");
    $stmt->execute([$userId, $userId, $userId, $userId, $userId]);
    $checks = $stmt->fetch();

    $isComplete = ($checks['has_basic'] && $checks['has_religion'] &&
                   $checks['has_location'] && $checks['has_education'] && $checks['has_habits']) ? 1 : 0;

    $stmt = $db->prepare("UPDATE user_profiles SET is_profile_complete = ? WHERE user_id = ?");
    $stmt->execute([$isComplete, $userId]);
}
