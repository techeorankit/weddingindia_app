-- ============================================================
--  Wedding India App - MySQL Database Schema
--  Version: 1.0
-- ============================================================

CREATE DATABASE IF NOT EXISTS wedding_india_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE wedding_india_db;

-- ============================================================
-- LOOKUP / DROPDOWN TABLES
-- ============================================================

-- Religions
CREATE TABLE religions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO religions (name, sort_order) VALUES
('Hindu', 1), ('Muslim', 2), ('Christian', 3), ('Sikh', 4),
('Jain', 5), ('Buddhist', 6), ('Other', 7);

-- Mother Tongues / Languages
CREATE TABLE mother_tongues (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO mother_tongues (name, sort_order) VALUES
('Hindi', 1), ('Marathi', 2), ('Gujarati', 3), ('Bengali', 4),
('Tamil', 5), ('Telugu', 6), ('Kannada', 7), ('Malayalam', 8),
('Punjabi', 9), ('Odia', 10), ('Urdu', 11), ('Assamese', 12),
('Maithili', 13), ('Sanskrit', 14), ('English', 15), ('Other', 16);

-- States (India)
CREATE TABLE states (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO states (name, sort_order) VALUES
('Andhra Pradesh', 1), ('Arunachal Pradesh', 2), ('Assam', 3),
('Bihar', 4), ('Chhattisgarh', 5), ('Goa', 6), ('Gujarat', 7),
('Haryana', 8), ('Himachal Pradesh', 9), ('Jharkhand', 10),
('Karnataka', 11), ('Kerala', 12), ('Madhya Pradesh', 13),
('Maharashtra', 14), ('Manipur', 15), ('Meghalaya', 16),
('Mizoram', 17), ('Nagaland', 18), ('Odisha', 19), ('Punjab', 20),
('Rajasthan', 21), ('Sikkim', 22), ('Tamil Nadu', 23), ('Telangana', 24),
('Tripura', 25), ('Uttar Pradesh', 26), ('Uttarakhand', 27),
('West Bengal', 28), ('Delhi', 29), ('Other', 30);

-- Education Levels
CREATE TABLE education_levels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO education_levels (name, sort_order) VALUES
('Below 10th', 1), ('10th Pass', 2), ('12th Pass', 3), ('Diploma', 4),
('Graduate', 5), ('Post Graduate', 6), ('Doctorate', 7), ('Other', 8);

-- Annual Income Ranges
CREATE TABLE income_ranges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO income_ranges (name, sort_order) VALUES
('No Income', 1), ('Below 1 Lakh', 2), ('1-2 Lakh', 3), ('2-5 Lakh', 4),
('5-10 Lakh', 5), ('10-20 Lakh', 6), ('20-50 Lakh', 7),
('50 Lakh - 1 Crore', 8), ('1-2 Crore', 9), ('2-3 Crore', 10),
('3-4 Crore', 11), ('4-5 Crore', 12), ('5+ Crore', 13);

-- Marital Status
CREATE TABLE marital_statuses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO marital_statuses (name, sort_order) VALUES
('Never Married', 1), ('Divorced', 2), ('Widowed', 3), ('Awaiting Divorce', 4);

-- Profile For (relationship options)
CREATE TABLE profile_for_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO profile_for_options (name, sort_order) VALUES
('Myself', 1), ('Son', 2), ('Daughter', 3), ('Brother', 4), ('Sister', 5), ('Friend', 6);

-- Heights
CREATE TABLE heights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    cm_value INT NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO heights (name, cm_value, sort_order) VALUES
("4'6\"", 137, 1), ("4'7\"", 140, 2), ("4'8\"", 142, 3),
("4'9\"", 145, 4), ("4'10\"", 147, 5), ("4'11\"", 150, 6),
("5'0\"", 152, 7), ("5'1\"", 155, 8), ("5'2\"", 157, 9),
("5'3\"", 160, 10), ("5'4\"", 163, 11), ("5'5\"", 165, 12),
("5'6\"", 168, 13), ("5'7\"", 170, 14), ("5'8\"", 173, 15),
("5'9\"", 175, 16), ("5'10\"", 178, 17), ("5'11\"", 180, 18),
("6'0\"", 183, 19), ("6'1\"", 185, 20), ("6'2\"", 188, 21),
("6'3\"", 191, 22), ("6'4\"", 193, 23);

-- Eating Habits
CREATE TABLE eating_habits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO eating_habits (name, sort_order) VALUES
('Vegetarian', 1), ('Non-Vegetarian', 2), ('Eggetarian', 3), ('Vegan', 4);

-- Smoking Habits
CREATE TABLE smoking_habits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO smoking_habits (name, sort_order) VALUES
('No', 1), ('Occasionally', 2), ('Yes', 3);

-- Drinking Habits
CREATE TABLE drinking_habits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO drinking_habits (name, sort_order) VALUES
('No', 1), ('Occasionally', 2), ('Yes', 3);

-- Body Types
CREATE TABLE body_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO body_types (name, sort_order) VALUES
('Slim', 1), ('Average', 2), ('Athletic', 3), ('Heavy', 4);

-- Complexions
CREATE TABLE complexions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO complexions (name, sort_order) VALUES
('Very Fair', 1), ('Fair', 2), ('Wheatish', 3), ('Dark', 4);

-- Blood Groups
CREATE TABLE blood_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(10) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO blood_groups (name, sort_order) VALUES
('A+', 1), ('A-', 2), ('B+', 3), ('B-', 4),
('AB+', 5), ('AB-', 6), ('O+', 7), ('O-', 8);

-- Disabilities
CREATE TABLE disabilities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO disabilities (name, sort_order) VALUES
('None', 1), ('Physically Challenged', 2), ('Visually Impaired', 3),
('Hearing Impaired', 4), ('Other', 5);

-- Country Codes
CREATE TABLE country_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    country_name VARCHAR(100) NOT NULL,
    code VARCHAR(10) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

INSERT INTO country_codes (country_name, code, sort_order) VALUES
('India', '+91', 1), ('USA', '+1', 2), ('UK', '+44', 3), ('Australia', '+61', 4);

-- ============================================================
-- MAIN USER TABLES
-- ============================================================

-- Users (authentication)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(15) NOT NULL UNIQUE,
    country_code VARCHAR(10) DEFAULT '+91',
    otp VARCHAR(6) DEFAULT NULL,
    otp_expires_at DATETIME DEFAULT NULL,
    is_verified TINYINT(1) DEFAULT 0,
    auth_token VARCHAR(255) DEFAULT NULL,
    token_expires_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- User Profiles
CREATE TABLE user_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    profile_for VARCHAR(50) DEFAULT NULL,      -- Myself, Son, Daughter etc.
    full_name VARCHAR(150) DEFAULT NULL,
    dob DATE DEFAULT NULL,
    gender ENUM('Male','Female','Other') DEFAULT NULL,
    bio TEXT DEFAULT NULL,
    profile_photo VARCHAR(255) DEFAULT NULL,
    is_profile_complete TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- User Religion & Community
CREATE TABLE user_religion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    religion_id INT DEFAULT NULL,
    caste VARCHAR(150) DEFAULT NULL,
    mother_tongue_id INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (religion_id) REFERENCES religions(id),
    FOREIGN KEY (mother_tongue_id) REFERENCES mother_tongues(id)
);

-- User Location
CREATE TABLE user_location (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    state_id INT DEFAULT NULL,
    city VARCHAR(150) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (state_id) REFERENCES states(id)
);

-- User Education & Career
CREATE TABLE user_education (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    education_id INT DEFAULT NULL,
    profession VARCHAR(150) DEFAULT NULL,
    income_id INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (education_id) REFERENCES education_levels(id),
    FOREIGN KEY (income_id) REFERENCES income_ranges(id)
);

-- User Habits & Physical Details
CREATE TABLE user_habits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    height_id INT DEFAULT NULL,
    weight VARCHAR(20) DEFAULT NULL,
    eating_habit_id INT DEFAULT NULL,
    smoking_habit_id INT DEFAULT NULL,
    drinking_habit_id INT DEFAULT NULL,
    disability_id INT DEFAULT NULL,
    marital_status_id INT DEFAULT NULL,
    body_type_id INT DEFAULT NULL,
    complexion_id INT DEFAULT NULL,
    blood_group_id INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (height_id) REFERENCES heights(id),
    FOREIGN KEY (eating_habit_id) REFERENCES eating_habits(id),
    FOREIGN KEY (smoking_habit_id) REFERENCES smoking_habits(id),
    FOREIGN KEY (drinking_habit_id) REFERENCES drinking_habits(id),
    FOREIGN KEY (disability_id) REFERENCES disabilities(id),
    FOREIGN KEY (marital_status_id) REFERENCES marital_statuses(id),
    FOREIGN KEY (body_type_id) REFERENCES body_types(id),
    FOREIGN KEY (complexion_id) REFERENCES complexions(id),
    FOREIGN KEY (blood_group_id) REFERENCES blood_groups(id)
);

-- User Partner Preferences
CREATE TABLE user_partner_preference (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    age_min INT DEFAULT 18,
    age_max INT DEFAULT 35,
    religion_id INT DEFAULT NULL,        -- NULL = Any
    min_height_id INT DEFAULT NULL,
    max_height_id INT DEFAULT NULL,
    income_id INT DEFAULT NULL,          -- NULL = Any
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (religion_id) REFERENCES religions(id),
    FOREIGN KEY (min_height_id) REFERENCES heights(id),
    FOREIGN KEY (max_height_id) REFERENCES heights(id),
    FOREIGN KEY (income_id) REFERENCES income_ranges(id)
);

-- User Photos
CREATE TABLE user_photos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    photo_path VARCHAR(255) NOT NULL,
    is_primary TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
