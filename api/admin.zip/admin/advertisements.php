<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Advertisements';
$db = getDB();

// ── Ensure table exists ─────────────────────────────────────────────────────
$db->exec("CREATE TABLE IF NOT EXISTS `advertisements` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title`       VARCHAR(200) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `media_type`  ENUM('image','video') NOT NULL DEFAULT 'image',
  `media_url`   VARCHAR(500) NOT NULL,
  `click_url`   VARCHAR(500) DEFAULT NULL,
  `advertiser`  VARCHAR(200) DEFAULT NULL,
  `phone`       VARCHAR(20)  DEFAULT NULL,
  `position`    INT NOT NULL DEFAULT 5,
  `is_active`   TINYINT(1) NOT NULL DEFAULT 1,
  `impressions` INT UNSIGNED NOT NULL DEFAULT 0,
  `clicks`      INT UNSIGNED NOT NULL DEFAULT 0,
  `starts_at`   DATETIME DEFAULT NULL,
  `ends_at`     DATETIME DEFAULT NULL,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$msg = '';
$msgType = '';

// ── Upload dir ─────────────────────────────────────────────────────────────
$uploadDir = __DIR__ . '/../uploads/ads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
$uploadUrl = 'https://weddingindiamatrimony.com/api/uploads/ads/';

// ── Handle POST ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';

    if ($act === 'add' || $act === 'edit') {
        $id          = (int)($_POST['id'] ?? 0);
        $title       = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $media_type  = in_array($_POST['media_type'] ?? '', ['image','video']) ? $_POST['media_type'] : 'image';
        $click_url   = trim($_POST['click_url'] ?? '');
        $advertiser  = trim($_POST['advertiser'] ?? '');
        $phone       = trim($_POST['phone'] ?? '');
        $position    = max(1, (int)($_POST['position'] ?? 5));
        $is_active   = isset($_POST['is_active']) ? 1 : 0;
        $starts_at   = $_POST['starts_at'] !== '' ? $_POST['starts_at'] : null;
        $ends_at     = $_POST['ends_at']   !== '' ? $_POST['ends_at']   : null;

        if ($title === '') { $msg = 'Title is required.'; $msgType = 'error'; }
        else {
            // Handle file upload
            $media_url = trim($_POST['existing_media_url'] ?? '');
            if (!empty($_FILES['media_file']['name'])) {
                $file     = $_FILES['media_file'];
                $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $allowed  = $media_type === 'video' ? ['mp4','mov','avi','webm'] : ['jpg','jpeg','png','gif','webp'];
                if (!in_array($ext, $allowed)) {
                    $msg = 'Invalid file type. Allowed: ' . implode(', ', $allowed);
                    $msgType = 'error';
                } elseif ($file['size'] > 50 * 1024 * 1024) {
                    $msg = 'File too large. Max 50MB.';
                    $msgType = 'error';
                } else {
                    $filename = uniqid('ad_', true) . '.' . $ext;
                    if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
                        // Delete old file if editing
                        if ($act === 'edit' && $media_url) {
                            $old = $uploadDir . basename($media_url);
                            if (file_exists($old)) @unlink($old);
                        }
                        $media_url = $uploadUrl . $filename;
                    } else {
                        $msg = 'File upload failed. Check server permissions.';
                        $msgType = 'error';
                    }
                }
            }
            if ($msgType !== 'error') {
                if ($media_url === '' && $act === 'add') {
                    $msg = 'Please upload a media file.'; $msgType = 'error';
                } else {
                    if ($act === 'add') {
                        $db->prepare("INSERT INTO advertisements (title,description,media_type,media_url,click_url,advertiser,phone,position,is_active,starts_at,ends_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
                           ->execute([$title,$description,$media_type,$media_url,$click_url,$advertiser,$phone,$position,$is_active,$starts_at,$ends_at]);
                        $msg = '✅ Advertisement added successfully!'; $msgType = 'success';
                    } else {
                        $db->prepare("UPDATE advertisements SET title=?,description=?,media_type=?,media_url=?,click_url=?,advertiser=?,phone=?,position=?,is_active=?,starts_at=?,ends_at=?,updated_at=NOW() WHERE id=?")
                           ->execute([$title,$description,$media_type,$media_url,$click_url,$advertiser,$phone,$position,$is_active,$starts_at,$ends_at,$id]);
                        $msg = '✅ Advertisement updated!'; $msgType = 'success';
                    }
                }
            }
        }
    }

    if ($act === 'delete') {
        $id = (int)($_POST['del_id'] ?? 0);
        if ($id > 0) {
            $row = $db->prepare("SELECT media_url FROM advertisements WHERE id=?");
            $row->execute([$id]);
            $r = $row->fetch();
            if ($r && $r['media_url']) {
                $f = $uploadDir . basename($r['media_url']);
                if (file_exists($f)) @unlink($f);
            }
            $db->prepare("DELETE FROM advertisements WHERE id=?")->execute([$id]);
            $msg = 'Advertisement deleted.'; $msgType = 'success';
        }
    }

    if ($act === 'toggle') {
        $id = (int)($_POST['toggle_id'] ?? 0);
        $db->prepare("UPDATE advertisements SET is_active = 1 - is_active WHERE id=?")->execute([$id]);
        header('Location: advertisements.php'); exit();
    }
}

// ── Fetch ───────────────────────────────────────────────────────────────────
$ads   = $db->query("SELECT * FROM advertisements ORDER BY created_at DESC")->fetchAll();
$total = count($ads);
$activeCount = count(array_filter($ads, fn($a) => $a['is_active']));
$totalImpressions = array_sum(array_column($ads, 'impressions'));
$totalClicks      = array_sum(array_column($ads, 'clicks'));

// Edit prefill
$editAd = null;
if (isset($_GET['edit'])) {
    $s = $db->prepare("SELECT * FROM advertisements WHERE id=?");
    $s->execute([(int)$_GET['edit']]);
    $editAd = $s->fetch();
}

include 'layout.php';
?>

<style>
.ad-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px;margin-bottom:24px}
.ad-card{background:#fff;border-radius:16px;box-shadow:0 2px 10px rgba(0,0,0,.06);overflow:hidden;border:1px solid #eef0f5}
.ad-thumb{width:100%;height:180px;object-fit:cover;background:#f5f5f5;display:block}
.ad-thumb-video{width:100%;height:180px;background:#1a1a2e;display:flex;align-items:center;justify-content:center;color:#fff;font-size:36px}
.ad-body{padding:16px}
.ad-title{font-size:15px;font-weight:700;color:#1a1a2e;margin-bottom:4px}
.ad-meta{font-size:12px;color:#888;margin-bottom:10px}
.ad-stats{display:flex;gap:16px;margin-bottom:12px}
.ad-stat{font-size:12px;color:#555}
.ad-stat strong{font-size:15px;font-weight:700;color:#1a1a2e;display:block}
.ad-actions{display:flex;gap:8px;flex-wrap:wrap}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.media-preview{max-width:100%;max-height:200px;border-radius:10px;margin-top:8px;object-fit:contain;border:1px solid #eee}
@media(max-width:600px){.form-row{grid-template-columns:1fr}}
</style>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType === 'success' ? 'success' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<!-- Stats -->
<div class="stats-row" style="grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:24px">
  <div class="stat">
    <div class="stat-ico" style="background:#fce4ec">📢</div>
    <div class="stat-info"><h3><?= $total ?></h3><p>Total Ads</p></div>
  </div>
  <div class="stat">
    <div class="stat-ico" style="background:#dcfce7">✅</div>
    <div class="stat-info"><h3><?= $activeCount ?></h3><p>Active</p></div>
  </div>
  <div class="stat">
    <div class="stat-ico" style="background:#dbeafe">👁️</div>
    <div class="stat-info"><h3><?= number_format($totalImpressions) ?></h3><p>Impressions</p></div>
  </div>
  <div class="stat">
    <div class="stat-ico" style="background:#f3e8ff">🖱️</div>
    <div class="stat-info"><h3><?= number_format($totalClicks) ?></h3><p>Clicks</p></div>
  </div>
</div>

<!-- Add / Edit Form -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h2><?= $editAd ? '✏️ Edit Advertisement' : '➕ Add New Advertisement' ?></h2>
    <?php if ($editAd): ?>
      <a href="advertisements.php" class="btn btn-secondary btn-sm">Cancel Edit</a>
    <?php endif; ?>
  </div>
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="act" value="<?= $editAd ? 'edit' : 'add' ?>">
      <?php if ($editAd): ?>
        <input type="hidden" name="id" value="<?= $editAd['id'] ?>">
        <input type="hidden" name="existing_media_url" value="<?= htmlspecialchars($editAd['media_url']) ?>">
      <?php endif; ?>

      <div class="form-row">
        <div class="form-group">
          <label>Ad Title *</label>
          <input type="text" name="title" required placeholder="e.g. Get 50% off on catering!"
            value="<?= htmlspecialchars($editAd['title'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Advertiser Name / Company</label>
          <input type="text" name="advertiser" placeholder="e.g. Sharma Catering"
            value="<?= htmlspecialchars($editAd['advertiser'] ?? '') ?>">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Advertiser Phone</label>
          <input type="text" name="phone" placeholder="+91 9XXXXXXXXX"
            value="<?= htmlspecialchars($editAd['phone'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Click URL (optional)</label>
          <input type="url" name="click_url" placeholder="https://..."
            value="<?= htmlspecialchars($editAd['click_url'] ?? '') ?>">
        </div>
      </div>

      <div class="form-group">
        <label>Description (optional)</label>
        <textarea name="description" rows="2" placeholder="Short description of the ad..."
          style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:10px;font-size:14px;outline:none;resize:vertical"><?= htmlspecialchars($editAd['description'] ?? '') ?></textarea>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Media Type *</label>
          <select name="media_type" id="mediaTypeSelect">
            <option value="image" <?= ($editAd['media_type'] ?? 'image') === 'image' ? 'selected' : '' ?>>🖼️ Image (JPG, PNG, GIF, WebP)</option>
            <option value="video" <?= ($editAd['media_type'] ?? '') === 'video' ? 'selected' : '' ?>>🎥 Video (MP4, MOV)</option>
          </select>
        </div>
        <div class="form-group">
          <label>Show After Every N Profiles</label>
          <input type="number" name="position" min="1" max="20" value="<?= $editAd['position'] ?? 4 ?>" placeholder="4">
        </div>
      </div>

      <div class="form-group">
        <label>Upload Media File * <?= $editAd ? '(Leave empty to keep current)' : '' ?></label>
        <input type="file" name="media_file" id="mediaFile" accept="image/*,video/*"
          <?= $editAd ? '' : 'required' ?>>
        <?php if ($editAd && $editAd['media_url']): ?>
          <div style="margin-top:8px">
            <small style="color:#888">Current file:</small><br>
            <?php if ($editAd['media_type'] === 'video'): ?>
              <video src="<?= htmlspecialchars($editAd['media_url']) ?>" style="max-height:120px;border-radius:8px;margin-top:4px" controls></video>
            <?php else: ?>
              <img src="<?= htmlspecialchars($editAd['media_url']) ?>" class="media-preview">
            <?php endif; ?>
          </div>
        <?php endif; ?>
        <div id="mediaPreviewWrap"></div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Start Date (optional)</label>
          <input type="datetime-local" name="starts_at"
            value="<?= $editAd && $editAd['starts_at'] ? date('Y-m-d\TH:i', strtotime($editAd['starts_at'])) : '' ?>">
        </div>
        <div class="form-group">
          <label>End Date (optional)</label>
          <input type="datetime-local" name="ends_at"
            value="<?= $editAd && $editAd['ends_at'] ? date('Y-m-d\TH:i', strtotime($editAd['ends_at'])) : '' ?>">
        </div>
      </div>

      <div class="form-group">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
          <input type="checkbox" name="is_active" value="1"
            <?= ($editAd ? $editAd['is_active'] : 1) ? 'checked' : '' ?> style="width:16px;height:16px">
          Active (show in app)
        </label>
      </div>

      <button type="submit" class="btn btn-primary">
        <?= $editAd ? '💾 Save Changes' : '➕ Add Advertisement' ?>
      </button>
    </form>
  </div>
</div>

<!-- Ads List -->
<?php if (empty($ads)): ?>
<div class="card"><div class="card-body empty">
  <div class="e-ico">📢</div>
  <p>No advertisements yet. Add your first ad above!</p>
</div></div>
<?php else: ?>
<div class="card">
  <div class="card-header"><h2>📋 All Advertisements (<?= $total ?>)</h2></div>
  <div class="tbl-scroll">
    <table>
      <thead>
        <tr>
          <th>Preview</th>
          <th>Title / Advertiser</th>
          <th>Type</th>
          <th>Stats</th>
          <th>Position</th>
          <th>Schedule</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($ads as $ad): ?>
        <tr>
          <td>
            <?php if ($ad['media_type'] === 'video'): ?>
              <div style="width:80px;height:50px;background:#1a1a2e;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px">▶️</div>
            <?php else: ?>
              <img src="<?= htmlspecialchars($ad['media_url']) ?>" style="width:80px;height:50px;object-fit:cover;border-radius:6px;border:1px solid #eee"
                onerror="this.style.display='none'">
            <?php endif; ?>
          </td>
          <td>
            <div style="font-weight:600;font-size:13px"><?= htmlspecialchars($ad['title']) ?></div>
            <?php if ($ad['advertiser']): ?>
              <div style="font-size:11px;color:#888">🏢 <?= htmlspecialchars($ad['advertiser']) ?></div>
            <?php endif; ?>
            <?php if ($ad['phone']): ?>
              <div style="font-size:11px;color:#888">📞 <?= htmlspecialchars($ad['phone']) ?></div>
            <?php endif; ?>
          </td>
          <td><span class="badge <?= $ad['media_type'] === 'video' ? 'bg-purple' : 'bg-blue' ?>"><?= ucfirst($ad['media_type']) ?></span></td>
          <td>
            <div style="font-size:12px">👁️ <?= number_format($ad['impressions']) ?></div>
            <div style="font-size:12px">🖱️ <?= number_format($ad['clicks']) ?></div>
            <?php if ($ad['impressions'] > 0): ?>
              <div style="font-size:11px;color:#888">CTR: <?= round($ad['clicks']/$ad['impressions']*100, 1) ?>%</div>
            <?php endif; ?>
          </td>
          <td>Every <?= $ad['position'] ?> profiles</td>
          <td style="font-size:11px;color:#888">
            <?= $ad['starts_at'] ? '▶ '.date('d M Y', strtotime($ad['starts_at'])) : 'Anytime' ?><br>
            <?= $ad['ends_at']   ? '⏹ '.date('d M Y', strtotime($ad['ends_at']))   : 'No end' ?>
          </td>
          <td>
            <form method="POST" style="display:inline">
              <input type="hidden" name="act" value="toggle">
              <input type="hidden" name="toggle_id" value="<?= $ad['id'] ?>">
              <button type="submit" class="badge <?= $ad['is_active'] ? 'bg-green' : 'bg-red' ?>" style="cursor:pointer;border:none">
                <?= $ad['is_active'] ? '✅ Active' : '❌ Paused' ?>
              </button>
            </form>
          </td>
          <td>
            <a href="?edit=<?= $ad['id'] ?>" class="btn btn-info btn-sm">✏️ Edit</a>
            <form method="POST" style="display:inline" onsubmit="return confirm('Delete this ad?')">
              <input type="hidden" name="act" value="delete">
              <input type="hidden" name="del_id" value="<?= $ad['id'] ?>">
              <button type="submit" class="btn btn-danger btn-sm">🗑️ Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<script>
// Media preview before upload
document.getElementById('mediaFile').addEventListener('change', function() {
  const wrap = document.getElementById('mediaPreviewWrap');
  wrap.innerHTML = '';
  if (!this.files[0]) return;
  const file = this.files[0];
  const url = URL.createObjectURL(file);
  if (file.type.startsWith('video/')) {
    wrap.innerHTML = `<video src="${url}" controls style="max-height:160px;border-radius:10px;margin-top:8px;max-width:100%"></video>`;
  } else {
    wrap.innerHTML = `<img src="${url}" style="max-height:160px;border-radius:10px;margin-top:8px;max-width:100%;object-fit:contain;border:1px solid #eee">`;
  }
});
</script>

<?php include 'layout_end.php'; ?>
